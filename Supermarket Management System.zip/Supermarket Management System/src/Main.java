import javax.swing.*;

import gui.AdminGUI;
import gui.CustomerGUI;

public class Main {
    public static void main(String[] args) {
        String choice = JOptionPane.showInputDialog("Enter 1 for Admin, 2 for Customer:");
        if ("1".equals(choice)) {
            AdminGUI adminGUI = new AdminGUI();
            adminGUI.setVisible(true);
        } else if ("2".equals(choice)) {
            CustomerGUI customerGUI = new CustomerGUI();
            customerGUI.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Invalid choice!");
        }
    }
}

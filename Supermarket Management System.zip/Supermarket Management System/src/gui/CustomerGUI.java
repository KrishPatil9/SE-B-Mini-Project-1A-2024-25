package gui;

import db.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerGUI extends JFrame {
    private JComboBox<String> itemComboBox;
    private JTextField customerNameField;
    private JTextField quantityField;
    private JTextArea receiptArea;

    public CustomerGUI() {
        setTitle("Customer Panel");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        customerNameField = new JTextField(15);
        itemComboBox = new JComboBox<>();
        quantityField = new JTextField(5);
        receiptArea = new JTextArea(10, 30);

        JButton generateBillButton = new JButton("Generate Bill");
        generateBillButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateBill();
            }
        });

        loadItems();

        add(new JLabel("Customer Name:"));
        add(customerNameField);
        add(new JLabel("Select Item:"));
        add(itemComboBox);
        add(new JLabel("Quantity:"));
        add(quantityField);
        add(generateBillButton);
        add(new JScrollPane(receiptArea));
    }

    private void loadItems() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = conn.prepareStatement("SELECT name FROM items");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                itemComboBox.addItem(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void generateBill() {
        String customerName = customerNameField.getText();
        String selectedItem = (String) itemComboBox.getSelectedItem();
        int quantity = Integer.parseInt(quantityField.getText());

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = conn.prepareStatement("SELECT price FROM items WHERE name = ?");
            pstmt.setString(1, selectedItem);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                double price = rs.getDouble("price");
                double totalPrice = price * quantity;

                // Save transaction to database
                String insertSQL = "INSERT INTO transactions (customer_name, item_id, quantity, total_price) VALUES (?, ?, ?, ?)";
                pstmt = conn.prepareStatement(insertSQL);
                pstmt.setString(1, customerName);
                pstmt.setInt(2, getItemId(selectedItem));
                pstmt.setInt(3, quantity);
                pstmt.setDouble(4, totalPrice);
                pstmt.executeUpdate();

                // Show the bill
                receiptArea.setText("Customer Name: " + customerName +
                                    "\nItem: " + selectedItem +
                                    "\nQuantity: " + quantity +
                                    "\nTotal Price: $" + totalPrice);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int getItemId(String itemName) {
        int itemId = -1;
        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = conn.prepareStatement("SELECT id FROM items WHERE name = ?");
            pstmt.setString(1, itemName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                itemId = rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return itemId;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomerGUI().setVisible(true));
    }
}
